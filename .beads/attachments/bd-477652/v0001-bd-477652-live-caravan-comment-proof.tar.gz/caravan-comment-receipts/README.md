# bd-477652 live Caravan control-label audit proof

Disposable PR: https://github.com/harryaskham/caravan/pull/7

Branch/head: `canary/cara-comment-audit-20260718` @ `098bc115e3656b9722766f793f0624ab699b1fb0`

Safety:
- Required `build-test` failed intentionally before enrollment.
- Protected `main` was unchanged.
- Force proof used a local `gh` permission wrapper: first ADMIN permission read allowed the real audit comment; second returned WRITE so Cara failed closed before admin merge.
- Final state before closure: only `caravan-evicted`, auto-merge disabled, head unchanged.

Live audit comments:
- new: https://github.com/harryaskham/caravan/pull/7#issuecomment-5011489076
- force_accept: https://github.com/harryaskham/caravan/pull/7#issuecomment-5011505914
- evict with force/priority: https://github.com/harryaskham/caravan/pull/7#issuecomment-5011511388
- renew clearing priority: https://github.com/harryaskham/caravan/pull/7#issuecomment-5011516594
- final evict: https://github.com/harryaskham/caravan/pull/7#issuecomment-5011518093

Exact retries:
- `new` retry: changed=false and comment already_satisfied; one new marker/comment remained.
- `force_accept` retry: comment already_satisfied; one force marker/comment remained; merge denied before provider merge.

Receipt files are numbered in execution order.
